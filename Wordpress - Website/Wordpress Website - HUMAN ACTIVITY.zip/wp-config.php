<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'id7106801_wp_87bfcd1a71963995909bf82405b587da' );

/** MySQL database username */
define( 'DB_USER', 'id7106801_wp_87bfcd1a71963995909bf82405b587da' );

/** MySQL database password */
define( 'DB_PASSWORD', 'f76f2af7be8b9a9a16d392fcc8276539b74ccfe2' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'pigV(E]P>fRUKQ[SYm.-cBM[cH&.sfH`e6&2C0gcl bTb3n%gx8{?)<H@$ZF}-S[' );
define( 'SECURE_AUTH_KEY',  'm_RdBR5t[6LC~ *?LLEW[<>aFK~E~8fzK#K*I6UL<`,ArYmrwAmfd@>w h=P{lgY' );
define( 'LOGGED_IN_KEY',    '?a4oWe)TV~A&2$x{o=%fYD$}7$0CW %;{TIsth2_Ig$_^F&|z.K%}$uj!>!)v%HS' );
define( 'NONCE_KEY',        '8%SD9}];`(M-vQsE$#Eay:zMC0:YixD&4gCFlIjybj{3b&|n%|k9z1U.MSM@bV>U' );
define( 'AUTH_SALT',        'XM#H6Vbx&Y4Q^doXbSa]J*0MV@_XfW3db>$Z:;mGp>01lwh!K@zwK@pdO-+Y6f/(' );
define( 'SECURE_AUTH_SALT', '*KeW:9yL/iaU.dwb2<wgn[a#J~c`WKLdR6!0ZOg#!.LW/$t/iO6;$S8rieMbqsm2' );
define( 'LOGGED_IN_SALT',   'R6f8/f&mR4 NgL[z+6Ojv)2HPh}&7);7H t cdo^N4x7T^nK3%n23x4#Aj&fnBhU' );
define( 'NONCE_SALT',       'e||OV+7,{x!JUK+RerfpYe*EG(?EGP*yc,4f~*t;g~K3F4Xo(G+JYZ6us`]Gvh2F' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) )
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';

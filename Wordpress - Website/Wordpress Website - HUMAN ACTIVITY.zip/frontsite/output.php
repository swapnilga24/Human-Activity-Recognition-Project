<!doctype html>
<?php include 'header.php'; ?>

<html>
<head><title>Result</title></head>
<body>

	<iframe src="https://humanactrec.shinyapps.io/humanactrec" width="90%" height="2000" frameborder="1" >result</iframe>


</body>
</html>

<?php include 'footer.php'; ?>
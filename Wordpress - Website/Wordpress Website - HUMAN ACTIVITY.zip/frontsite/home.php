<!doctype html>
<?php include 'header.php'; ?>

<html>
<head><title>Home</title></head>
<body>
<div>
	this is home and contains some info.

</div>
</body>
</html>

<?php include 'footer.php'; ?>
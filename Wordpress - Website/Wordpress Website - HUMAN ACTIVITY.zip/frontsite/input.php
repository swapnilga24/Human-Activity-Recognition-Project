<!DOCTYPE html>
<?php include 'header.php'; ?>

<html>
<head><title>Input</title></head>
<body>

	<iframe src="http://komalgodse7.000webhostapp.com" width="90%" height="2000" frameborder="1" >upload</iframe>

</body>
</html>

<?php include 'footer.php'; ?>